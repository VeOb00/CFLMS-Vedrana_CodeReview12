<div class="container">
    <div class="row">

        <?php if (have_posts()): while (have_posts()): the_post(); ?>

            <div class="col-md-6 col-lg-4 mb-5 ">
                <div class="card mx-2 text-center">
                    <?php if (has_post_thumbnail()): ?>
                        <a href="<?php the_permalink(); ?>">
                            <img src="<?php the_post_thumbnail_url('large'); ?>"
                                 class="card-img-top w-100 rounded-0" alt="<?php the_title(); ?>">
                        </a>
                    <?php endif; ?>
                    <div class="card-body pb-0 pt-1">
                        <small class="text-muted"><?php the_category(); ?></small>
                        <h5 class="card-title text-uppercase"><?php the_title(); ?></h5>
                        <p class="card-text mb-0 pb-0"><?php the_excerpt(); ?></p>
                    </div>
                    <div class="card-footer pt-0">
                        <small class="text-muted"><?php echo get_the_date('l jS F, Y'); ?></small><br>
                    </div>
                </div>
            </div>

        <?php endwhile; else: endif; ?>

    </div>
</div>




